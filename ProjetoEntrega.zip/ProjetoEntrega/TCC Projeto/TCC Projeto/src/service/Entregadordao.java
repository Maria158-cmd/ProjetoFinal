package service;

import config.conexaobd;
import Classes.Pessoa.entregador;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Entregadordao {
    public static void salvar (entregador entregador)
        throws SQLException, Exception{

        String sql = "INSERT INTO ENTREGADOR (nome, cpf, dataNascimento, telefoneCelular, observacao)" + "VALUES (?,?,?,?);";

        conexaobd conexao = null;
        PreparedStatement ps = null;

        try{
            conexao = conexaobd.obterConexao();
            ps = conexao.prepareStatement(sql);

            ps.setString(1, entregador.getNome());
            ps.setString(2, entregador.getCpf());
            ps.setString(3, entregador.getDataNascimento());
            ps.setString(4, entregador.getTelefoneCelular());
            ps.setString(5, entregador.getObservacao());

            ps.execute();
        }finally {
            if (ps != null && !ps.isClosed()){
                ps.close();
            }
            if (conexao != null && !conexao.isClosed()){
                conexao.close();
            }
        }
    }

    public static List<entregador> listar()
        throws SQLException,Exception{

        String sql = "SELECT id, nome, cpf, dataNascimento, telefoneCelular, observacao" + "FROM ENTREGADOR";
        List<entregador> entregadorList = null;

        conexaobd conexao = null;
        PreparedStatement ps = null;
        ResultSet resultado = null;

        try {
            conexao = conexaobd.obterConexao();
            ps = conexao.prepareStatement(sql);
            resultado = ps.executeQuery();

            while (resultado.next()){
                if (entregadorList == null){
                    entregadorList = new ArrayList<entregador>();
                }
                entregador entregador = new entregador();
                entregador.setId(resultado.getInt("id"));
                entregador.setNome(resultado.getString("nome"));
                entregador.setCpf(resultado.getString("cpf"));
                entregador.setDataNascimento(resultado.getString("dataNascimento"));
                entregador.setTelefoneCelular(resultado.getString("telefoneCelular"));
                entregador.setObservacao(resultado.getString("observacao"));

                entregadorList.add(entregador);
            }
        }finally {
            if (resultado != null && !resultado.isClosed()){
                resultado.close();
            }
            if (ps != null && !ps.isClosed()){
                ps.close();
            }
            if (conexao != null && !conexao.isClosed()){
                conexao.close();
            }
        }
        return entregadorList;
    }

    public static List<entregador> procurar (String nome)
        throws SQLException, Exception{
        String sql = "SELECT id, nome, cpf, dataNAscimento, telefoneCelular, observacao" + "FROM ENTREGADOR WHERE nome LIKE (?)";
        List<entregador> entregadorList = null;

        conexaobd conexao = null;
        PreparedStatement ps = null;
        ResultSet resultado = null;

        try {
            conexao = conexaobd.obterConexao();
            ps = conexao.prepareStatement(sql);

            ps.setString(1, "%" + nome + "%");
            resultado = ps.executeQuery();

            while (resultado.next()){
                if (entregadorList == null){
                    entregadorList = new ArrayList<entregador>();
                }
                entregador entregador = new entregador();
                entregador.setId(resultado.getInt("id"));
                entregador.setNome(resultado.getString("nome"));
                entregador.setCpf(resultado.getString("cpf"));
                entregador.setDataNascimento(resultado.getString("dataNascimento"));
                entregador.setTelefoneCelular(resultado.getString("telefoneCelular"));
                entregador.setObservacao(resultado.getString("observacao"));

                entregadorList.add(entregador);
            }
        }finally {
            if (resultado != null && !resultado.isClosed()){
                resultado.close();
            }
            if (ps != null && !ps.isClosed()){
                ps.close();
            }
            if (conexao != null && !conexao.isClosed()){
                conexao.close();
            }
        }
        return entregadorList;
    }

    public static entregador obter(Integer id)
        throws SQLException, Exception{

        String sql = "SELECT * FROM ENTREGADOR WHERE id =?";

        conexaobd conexao = null;
        PreparedStatement ps = null;
        ResultSet resultado = null;

        try {
            conexao = conexaobd.obterConexao();
            ps = conexao.prepareStatement(sql);

            ps.setInt(1, id);
            resultado = ps.executeQuery();

            if (resultado.next()){
                entregador entregador = new entregador();
                entregador.setId(resultado.getInt("id"));
                entregador.setNome(resultado.getString("nome"));
                entregador.setCpf(resultado.getString("cpf"));
                entregador.setDataNascimento(resultado.getString("dataNascimento"));
                entregador.setTelefoneCelular(resultado.getString("telefoneCelular"));
                entregador.setObservacao(resultado.getString("observacao"));

                return entregador;
            }
        }finally {
            if (resultado != null && !resultado.isClosed()){
                resultado.close();
            }
            if (ps != null && !ps.isClosed()){
                ps.close();
            }
            if (conexao != null && !conexao.isClosed()){
                conexao.close();
            }
        }
        return null;
    }

    public static entregador obter2(String cpf)
        throws SQLException, Exception{

        String sql = "SELECT * FROM ENTREGADOR WHERE cpf =?";

        conexaobd conexao = null;
        PreparedStatement ps = null;
        ResultSet resultado = null;

        try{
            conexao = conexaobd.obterConexao();
            ps = conexao.prepareStatement(sql);

            ps.setString(1, cpf);
            resultado = ps.executeQuery();

            if (resultado.next()){
                entregador entregador = new entregador();
                entregador.setId(resultado.getInt("id"));
                entregador.setNome(resultado.getString("nome"));
                entregador.setCpf(resultado.getString("cpf"));
                entregador.setDataNascimento(resultado.getString("dataNascimento"));
                entregador.setTelefoneCelular(resultado.getString("telefoneCelular"));
                entregador.setObservacao(resultado.getString("observacao"));

                return entregador;
            }
        }finally {
            if (resultado != null && !resultado.isClosed()){
                resultado.close();
            }
            if (ps != null && !ps.isClosed()){
                ps.close();
            }
            if (conexao != null && !conexao.isClosed()){
                conexao.close();
            }
        }
        return null;
    }
    public static void atualizar(entregador entregadorAtualizado)
            throws SQLException, Exception {

        String sql = "UPDATE DBPERFUMARIA.TBCLIENTES SET nome = ?, cpf = ? ,dataNascimento = ?,telefoneCelular = ?, observacoes = ? WHERE id = ?;";

        conexaobd conexao = null;
        PreparedStatement ps = null;

        try {

            conexao = conexaobd.obterConexao();
            ps = conexao.prepareStatement(sql);

            ps.setString(1, entregadorAtualizado.getNome());
            ps.setString(2, entregadorAtualizado.getCpf());
            ps.setString(3, entregadorAtualizado.getDataNascimento());
            ps.setString(4, entregadorAtualizado.getTelefoneCelular());
            ps.setString(5,entregadorAtualizado.getObservacao());

           ps.executeUpdate();
        } finally {
            if (ps != null && !ps.isClosed()) {
                ps.close();
            }
            if (conexao != null && !conexao.isClosed()) {
                conexao.close();
            }
        }
    }

    public static void excluir(Integer id)
            throws SQLException, Exception {
        String sql = "DELETE FROM DBPERFUMARIA.TBCLIENTES WHERE id = ?";

        conexaobd conexao = null;
        PreparedStatement ps = null;

        try {
            conexao = conexaobd.obterConexao();
            ps = conexao.prepareStatement(sql);
            ps.setInt(1, id);

            ps.executeUpdate();
        } finally {
            if (ps != null && !ps.isClosed()) {
                ps.close();
            }
            if (conexao != null && !conexao.isClosed()) {
                conexao.close();
            }
        }
    }
}


