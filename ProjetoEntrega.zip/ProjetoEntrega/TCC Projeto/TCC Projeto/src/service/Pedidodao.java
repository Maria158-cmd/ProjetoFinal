package service;

import config.conexaobd;
import Classes.Pedido.pedido;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Pedidodao {

    public static void salvar(pedido pedido)
        throws SQLException, Exception{

        String sql = "INSERT INTO PEDIDO (id, data, qtditens,  subtotal, taxaentrega, valortotal,pagamentoDinheiro, pagamentoCartao,"
                +   "nomeCliente, cpfCliente, nomeEntregador, telefoneEntregador, ruaEndereco, numeroEndereco, bairroEndereco"
                + "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);";

        conexaobd conexao = null;
        PreparedStatement ps = null;
        ResultSet resultado = null;

        try{
            conexao = conexaobd.obterConexao();
            ps = conexao.prepareStatement(sql);


            ps.setInt(1, pedido.getId());
            java.sql.Timestamp data = new java.sql.Timestamp(pedido.getData().getTime());
            ps.setTimestamp(2, data);
            ps.setInt(3, pedido.getItempedidos().size());
            ps.setFloat(4,pedido.getSubtotal(resultado.getFloat("subTotal")));
            ps.setFloat(5, pedido.getTaxaentrega());
            ps.setFloat(6, pedido.getValortotal());
            ps.setFloat(7, pedido.getPagamentoDinheiro());
            ps.setFloat(8, pedido.getPagamentoCartao());
            ps.setString(9,pedido.getCliente().getNome());
            ps.setString(10,pedido.getCliente().getCpf());
            ps.setString(11,pedido.getEntregador().getNome());
            ps.setString(12,pedido.getEntregador().getTelefoneCelular());
            ps.setString(13,pedido.getEndereco().getRua());
            ps.setString(14,pedido.getEndereco().getNumero());
            ps.setString(15,pedido.getEndereco().getBairro());

            ps.execute();
        }finally {
            if (ps != null && !ps.isClosed()){
                ps.close();
            }
            if (conexao != null && !conexao.isClosed()){
                conexao.close();
            }
        }
    }

    public static pedido obetrUltima()
        throws SQLException, Exception{

        String sql = "SELECT MAX(id) qtdpedido FROM PEDIDO";

        conexaobd conexao = null;
        PreparedStatement ps = null;
        ResultSet resultado = null;

        try{
            conexao = conexaobd.obterConexao();
            ps = conexao.prepareStatement(sql);
            resultado = ps.executeQuery();

            if (resultado.next()){
                pedido pedido = new pedido();
                pedido.setId(resultado.getInt("gtdpedido"));

                return pedido;
            }
        }finally {
            if (resultado != null && !resultado.isClosed()){
                resultado.close();
            }
            if (ps != null && !ps.isClosed()){
                ps.close();
            }
            if (conexao != null && !ps.isClosed()){
                conexao.close();
            }
        }
        return null;
    }
    public static List<pedido> listar()
        throws SQLException, Exception{

        String sql = "SELECT id, data, qtditens,  subtotal, taxaentrega, valortotal,pagamentoDinheiro, pagamentoCartao,"
                + "nomeCliente, cpfCliente, nomeEntregador, telefoneEntregador, ruaEndereco, numeroEndereco, bairroEndereco"
                + "FROM PEDIDO";
        List<pedido> pedidoList = null;

        conexaobd conexao = null;
        PreparedStatement ps = null;
        ResultSet resultado = null;

        try {
            conexao = conexaobd.obterConexao();
            ps = conexao.prepareStatement(sql);
            resultado = ps.executeQuery();

            while (resultado.next()){
                if (pedidoList == null){
                    pedidoList = new ArrayList<pedido>();
                }
                pedido pedido = new pedido();
                pedido.setId(resultado.getInt("id"));
                Date data = new Date(resultado.getTimestamp("data").getTime());
                pedido.setData(data);
                pedido.getQtdItens(resultado.getInt("qtditens"));
                pedido.getSubtotal(resultado.getFloat("subTotal"));
                pedido.getTaxaentrega(resultado.getFloat("taxaEntrega"));
                pedido.getValortotal(resultado.getFloat("valorTotal"));
                pedido.getPagamentoDinheiro(resultado.getFloat("pagamentoDinheiro"));
                pedido.getPagamentoCartao(resultado.getFloat("pagamentoCartao"));
                pedido.getCliente().setNome(resultado.getString("nomeCliente"));
                pedido.getCliente().setCpf(resultado.getString("cpfCliente"));
                pedido.getEntregador().setNome(resultado.getString("nomeEntregador"));
                pedido.getEntregador().setTelefoneCelular(resultado.getString("telefoneEntregador"));
                pedido.getEndereco().setRua(resultado.getString("ruaEndereco"));
                pedido.getEndereco().setNumero(resultado.getString("numeroEndereco"));
                pedido.getEndereco().setBairro(resultado.getString("bairroEndereco"));
                pedidoList.add(pedido);

            }
        }finally {
            if (resultado != null && !resultado.isClosed()){
                resultado.close();
            }
            if (ps != null && !ps.isClosed()){
                ps.close();
            }
            if (conexao != null && !conexao.isClosed()){
                conexao.close();
            }
        }
        return  pedidoList;
    }

    public static List<pedido> procurar(String dataInicio, String dataFim)
        throws SQLException, Exception{

        String sql = "SELECT Id, data, qtditens,  subtotal, taxaentrega, valortotal,pagamentoDinheiro, pagamentoCartao,"
                + "nomeCliente, cpfCliente, nomeEntregador, telefoneEntregador, ruaEndereco, numeroEndereco, bairroEndereco"
                + "FROM PEDIDO WHERE data BETWEEN ? AND?";
        List<pedido> pedidoList = null;
        conexaobd conexao = null;
        PreparedStatement ps = null;
        ResultSet resultado = null;

        try{
            conexao = conexaobd.obterConexao();
            ps = conexao.prepareStatement(sql);

            ps.setString(1, dataInicio + "00:00:00");
            ps.setString(2, dataFim + "23:59:59");

            resultado = ps.executeQuery();

            while (resultado.next()){
                if (pedidoList == null){
                    pedidoList = new ArrayList<pedido>();
                }
                pedido pedido = new pedido();
                pedido.setId(resultado.getInt("id"));
                Date data = new Date(resultado.getTimestamp("data").getTime());
                pedido.setData(data);
                pedido.getQtdItens(resultado.getInt("qtditens"));
                pedido.getSubtotal(resultado.getFloat("subTotal"));
                pedido.getTaxaentrega(resultado.getFloat("taxaEntrega"));
                pedido.getValortotal(resultado.getFloat("valorTotal"));
                pedido.getPagamentoDinheiro(resultado.getFloat("pagamentoDinheiro"));
                pedido.getPagamentoCartao(resultado.getFloat("pagamentoCartao"));
                pedido.getCliente().setNome(resultado.getString("nomeCliente"));
                pedido.getCliente().setCpf(resultado.getString("cpfCliente"));
                pedido.getEntregador().setNome(resultado.getString("nomeEntregador"));
                pedido.getEntregador().setTelefoneCelular(resultado.getString("telefoneEntregador"));
                pedido.getEndereco().setRua(resultado.getString("ruaEndereco"));
                pedido.getEndereco().setNumero(resultado.getString("numeroEndereco"));
                pedido.getEndereco().setBairro(resultado.getString("bairroEndereco"));
                pedidoList.add(pedido);
            }
        }finally {
            if(resultado != null && !resultado.isClosed()){
                resultado.close();
            }
            if (ps != null && !ps.isClosed()) {
                ps.close();
            }
            if (conexao != null && !conexao.isClosed()) {
                conexao.close();
            }
        }
        return pedidoList;
    }
}