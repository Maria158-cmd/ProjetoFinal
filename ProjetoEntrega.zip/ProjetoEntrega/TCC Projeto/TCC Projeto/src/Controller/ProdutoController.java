package Controller;
import service.Pedidodao;
import Classes.Produto.produto;
import service.Produtodao;

import java.util.List;

public class ProdutoController {

    public  static String salvar(produto produto){

        String resposta = null;

        try {
            Produtodao.salvar(produto);
        }catch (Exception e){
            e.printStackTrace();
            resposta = "Erro na fonte de dados";
        }
        return resposta;
    }

    public  static List<produto> procurar(String nome){
        List<produto> produtoList = null;

        try{
            if (nome == null || "".equals(nome)){
               produtoList = Produtodao.listar();
            }else {
                produtoList = Produtodao.procurar(nome);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return produtoList;
    }

    public  static String atualizar(produto produto){
        String resposta = null;

        try{
           // Produtodao.atualizar(produto);
        }catch (Exception e){
            e.printStackTrace();
            resposta = "Erro na fonte de dados";
        }
        return resposta;
    }

    public static String excluir(Integer id) {
        String resposta = null;

        try {
          Produtodao.excluir(id);
        }catch (Exception e){
            e.printStackTrace();
            resposta = "Erro na fonte de dados";
        }
        return resposta;
    }

    public  static produto obter(Integer id){
        produto produto = new produto();

        try{
           produto = Produtodao.obter(id);
        }catch (Exception e){
            e.printStackTrace();
        }
        return produto;
    }
}
