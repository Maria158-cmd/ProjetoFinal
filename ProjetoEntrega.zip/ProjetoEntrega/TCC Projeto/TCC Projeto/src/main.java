import Classes.Pessoa.endereco;
import config.conexaobd;

public class main {
    public static void main(String[] args) {
        conexaobd conexao = new conexaobd();

        conexao.getConexao();
    }



}
