package Classes.Pessoa;
import Classes.Enum.categoria;

public class cliente {
    private endereco endereco;
    private Integer Id;
    private String nome;
    private String datanascimento;
    private String cpf;
    private String telefone;
    private categoria categoria;

    public cliente(Classes.Pessoa.endereco endereco, Integer id, String nome, String datanascimento, String cpf, String telefone, Classes.Enum.categoria categoria) {
        this.endereco = endereco;
        Id = id;
        this.nome = nome;
        this.datanascimento = datanascimento;
        this.cpf = cpf;
        this.telefone = telefone;
        this.categoria = categoria;
    }

    public cliente() {

    }

    public Classes.Pessoa.endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Classes.Pessoa.endereco endereco) {
        this.endereco = endereco;
    }

    public Integer getId(int i) {
        return Id;
    }

    public void setId(Integer id) {
        Id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getDatanascimento() {
        return datanascimento;
    }

    public void setDatanascimento(String datanascimento) {
        this.datanascimento = datanascimento;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public Classes.Enum.categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Classes.Enum.categoria categoria) {
        this.categoria = categoria;
    }

    public cliente(Classes.Pessoa.endereco endereco, Integer id) {
        this.endereco = endereco;
        Id = id;
    }
}
