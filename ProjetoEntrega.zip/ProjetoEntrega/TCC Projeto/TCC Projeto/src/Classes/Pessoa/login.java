package Classes.Pessoa;

public class login {

    rivate Integer id;
    private Integer usuario;
    private Integer senha;

    public login(Integer id, Integer usuario, Integer senha) {
        this.id = id;
        this.usuario = usuario;
        this.senha = senha;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUsuario() {
        return usuarpio;
    }

    public void setUsuario(Integer usuario) {
        this.usuario = usuario;
    }

    public Integer getSenha() {
        return senha;
    }

    public void setSenha(Integer senha) {
        this.senha = senha;
    }
}
