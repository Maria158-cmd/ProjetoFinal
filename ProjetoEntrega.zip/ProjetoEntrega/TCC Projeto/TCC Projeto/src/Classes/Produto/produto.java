package Classes.Produto;

public class produto {


    private Integer Id;
    private String refrencia;
    private String descricao;
    private float valoruniti;
    private Integer quantestoque;

    public produto(Integer id, String refrencia, String descricao, float valoruniti, Integer quantestoque) {
        Id = id;
        this.refrencia = refrencia;
        this.descricao = descricao;
        this.valoruniti = valoruniti;
        this.quantestoque = quantestoque;
    }

    public produto() {

    }

    public Integer getId() {
        return Id;
    }

    public void setId(Integer id) {
        Id = id;
    }

    public String getRefrencia() {
        return refrencia;
    }

    public void setRefrencia(String refrencia) {
        this.refrencia = refrencia;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public float getValoruniti() {
        return valoruniti;
    }

    public void setValoruniti(float valoruniti) {
        this.valoruniti = valoruniti;
    }

    public Integer getQuantestoque() {
        return quantestoque;
    }

    public void setQuantestoque(Integer quantestoque) {
        this.quantestoque = quantestoque;
    }
}
