package Classes.Enum;

public enum categoria {
    Cliente,
    Vendedor,
    Fornecedor,
    Gerente,
}
