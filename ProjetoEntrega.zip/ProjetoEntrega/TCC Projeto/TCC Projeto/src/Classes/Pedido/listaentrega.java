package Classes.Pedido;

public class listaentrega {
    private Integer descricao;

    public listaentrega(Integer descricao) {
        this.descricao = descricao;
    }
}
