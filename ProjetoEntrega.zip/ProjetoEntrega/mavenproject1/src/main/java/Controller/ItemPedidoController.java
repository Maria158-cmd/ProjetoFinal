package Controller;

import service.Itempedidodao;
import Classes.Pedido.itempedido;
import java.util.List;

public class ItemPedidoController {

    public static String salvar(itempedido itempedido){
        String resposta = null;

        try{
            Itempedidodao.salvar(itempedido);
        }catch (Exception e){
            e.printStackTrace();
            resposta = "Erro na fonte de dados";
        }
        return resposta;
    }

    public static List<itempedido> obterItem(int idPedido){
        List<itempedido> listaResposta = null;

        try{
            listaResposta = Itempedidodao.obterItem(idPedido);
        }catch (Exception e){
            e.printStackTrace();
        }
        return  listaResposta;
    }
}
