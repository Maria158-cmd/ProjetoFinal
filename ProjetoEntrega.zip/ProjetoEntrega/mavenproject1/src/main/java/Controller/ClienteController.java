package Controller;

import Classes.Pessoa.cliente;
import service.Clientedao;
import java.util.List;
public class ClienteController {

    public static String salvar (cliente cliente){
        String resposta = null;

        try {
            Clientedao.salvar(cliente);

        }catch (Exception e){
            e.printStackTrace();
            resposta = "Erro na fonte de dados";
        }
        return resposta;
    }

    public static List<cliente> procurar(String nome){
        List<cliente> listaResposta = null;

        try{
            if (nome == null || "".equals(nome)){
                listaResposta = Clientedao.listar();
            }else {
                listaResposta = Clientedao.procurar(nome);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return listaResposta;
    }

    public static String atualizar(cliente cliente){
        String resposta = null;

        try{
            Clientedao.atualizar(cliente);
        }catch (Exception e){
            e.printStackTrace();
            resposta = "Erro na fonte de dados";
        }
        return resposta;
    }

    public static String excluir(Integer id){
        String resposta = null;

        try{
            Clientedao.excluir(id);
        }catch (Exception e){
            e.printStackTrace();
            resposta = "Erro na fonte de dados";
        }
        return resposta;
    }

    public static cliente obter(Integer id){
        cliente cliente = new cliente();

        try{
            cliente = Clientedao.obter(id);
        }catch (Exception e){
            e.printStackTrace();
        }
        return cliente;
    }

    public static cliente obter2 (String cpf){
        cliente cliente = new cliente();

        try{
            cliente = Clientedao.obter2(cpf);
        }catch (Exception e){
            return cliente = null;
        }

        return cliente;
    }

}
