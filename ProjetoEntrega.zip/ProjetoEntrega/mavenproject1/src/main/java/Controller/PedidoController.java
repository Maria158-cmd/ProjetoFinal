package Controller;

import service.Pedidodao;
import Classes.Pedido.pedido;
import java.util.Date;
import java.util.List;

public class PedidoController {

    public static String salvar(pedido pedido){

        String resposta = null;

        try {
            Pedidodao.salvar(pedido);
        }catch (Exception e){
            e.printStackTrace();
            resposta = "Erro na fonte de dados";
        }
        return resposta;
    }

    public static List<pedido> produrar(String dataInicio, String dataFim){
        List<pedido> listaResposta = null;

        try {
            if (dataInicio == null || dataFim == null){
                listaResposta = Pedidodao.listar();
            }else {
                listaResposta = Pedidodao.procurar(dataInicio, dataFim);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return listaResposta;
    }

    public static pedido obterUltima(){
        pedido pedido = new pedido();

        try {
            pedido = Pedidodao.obetrUltima();
        }catch (Exception e){
            e.printStackTrace();
        }
        return pedido;
    }

}
