package Controller;

import Classes.Pessoa.entregador;
import service.Entregadordao;
import java.util.List;

public class EntregadorController {

    public static String salvar(entregador entregador){

        String resposta = null;

        try{
            Entregadordao.salvar(entregador);
        }catch (Exception e){
            e.printStackTrace();
            resposta = "Erro na fonte de dados";
        }
        return resposta;
    }

    public static List<entregador> procurar(String nome){
        List<entregador> listaReposta = null;

        try {
            if (nome == null || "" .equals(nome)){
                listaReposta = Entregadordao.listar();
            }else {
                listaReposta = Entregadordao.procurar(nome);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return  listaReposta;
    }

    public static String atualizar(entregador entregador){
        String resposta = null;

        try {
            Entregadordao.atualizar(entregador);
        }catch (Exception e){
            e.printStackTrace();
            resposta = "Erro na fonte de dados";
        }
        return  resposta;
    }

    public static String excluir(Integer id){
        String resposta = null;

        try {
            Entregadordao.excluir(id);
        }catch (Exception e){
            e.printStackTrace();
            resposta = "Erro na fonte de dados";
        }
        return resposta;
    }

    public static entregador obter(Integer id){

        entregador entregador = new entregador();

        try {
            entregador = Entregadordao.obter(id);
        }catch (Exception e){
            e.printStackTrace();
        }
        return  entregador;
    }

    public static entregador obter2(String cpf){

        entregador entregador = new entregador();

        try {
            entregador = Entregadordao.obter2(cpf);
        }catch (Exception e){
            return entregador = null;
        }
        return  entregador;
    }

}