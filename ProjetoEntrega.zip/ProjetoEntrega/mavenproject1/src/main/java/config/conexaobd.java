package config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class conexaobd {
    public Connection conn;

    public Connection getConexao() {
        try {
            Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/EasySellbd", "postgres", "postgres");
            System.out.println("conectado com sucesso!");
            return connection;
        } catch (SQLException e) {
            System.out.println("Erro ao conectar com o banco de dados!\nErro: " + e);
        }
        return null;
    }

    public PreparedStatement prepareStatement(String sql) {
        return null;
    }

    public static conexaobd obterConexao() {
        return null;
    }

    public boolean isClosed() {
        return false;
    }

    public void close() {
    }
}