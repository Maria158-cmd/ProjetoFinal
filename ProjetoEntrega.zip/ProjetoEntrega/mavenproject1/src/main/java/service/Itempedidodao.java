package service;

import config.conexaobd;
import Classes.Pedido.itempedido;
import Classes.Produto.produto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Itempedidodao {
    public static  void salvar (itempedido itempedido)
        throws SQLException, Exception{
        String sql = "INSERT INTO ITEMPEDIDO (idPedido, idItem, descricaoProduto, idProduto, qtdItens, valorUniti, valorTotal)"
                    + "VALUES (?,?,?,?,?,?,?);";
        conexaobd conexao = null;
        PreparedStatement ps = null;

        try {
            conexao = conexaobd.obterConexao();
            ps = conexao.prepareStatement(sql);

            ps.setInt(1, itempedido.getIdPedido());
            ps.setInt(2, itempedido.getIdItem());
            ps.setString(3, itempedido.getDescricao());
            ps.setInt(4, itempedido.getId());
            ps.setInt(5, itempedido.getQuantestoque());
            ps.setFloat(6,itempedido.getValoruniti());
            ps.setFloat(7, itempedido.getValorTotal());

            ps.execute();
        }finally {
            if (ps != null && !ps.isClosed()){
                ps.close();
            }
            if (conexao != null && !conexao.isClosed()){
                conexao.close();
            }
        }
    }

    public static List<itempedido> obterItem(Integer id)
        throws SQLException, Exception{

        String sql = "SELECT idPedido, idItem, descricaoProduto, idProduto, qtdItens, valorUniti, valorTotal"
                + "FROM ITEMPEDIDO WHERE idPedido = ?";
        List<itempedido> itempedidoList = null;
        conexaobd conexao = null;
        PreparedStatement ps = null;
        ResultSet resultado = null;

        try {
            conexao = conexaobd.obterConexao();
            ps = conexao.prepareStatement(sql);
            ps.setInt(1, id);
            resultado = ps.executeQuery();

            while (resultado.next()){
                if (itempedidoList == null){
                    itempedidoList = new ArrayList<itempedido>();
                }
                itempedido itempedido = new itempedido();
                itempedido.setIdPedido(resultado.getInt("idPedido"));
                itempedido.setIdItem(resultado.getInt("idItem"));
                itempedido.setDescricao(resultado.getString("descricaoProduto"));
                itempedido.setId(resultado.getInt("idProduto"));
                itempedido.setQuantestoque(resultado.getInt("qtdItens"));
                itempedido.setValoruniti(resultado.getFloat("valorUniti"));
                itempedido.setValorTotal(resultado.getFloat("valorToral"));

                itempedidoList.add(itempedido);
            }
        }finally {
            if (resultado != null && !resultado.isClosed()){
                resultado.close();
            }
            if (ps != null && !resultado.isClosed()){
                ps.close();
            }
            if (conexao != null && !conexao.isClosed()){
                conexao.close();
            }
        }
        return itempedidoList;
    }

    public static List<itempedido> obterItem(int idPedido) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
