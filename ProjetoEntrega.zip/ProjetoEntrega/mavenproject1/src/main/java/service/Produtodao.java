package service;

import Classes.Produto.produto;
import config.conexaobd;
import jdk.jshell.spi.SPIResolutionException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class Produtodao {
    
    public static void salvar(produto produto)
            throws SQLException, Exception {
        String sql = "INSERT INTO PRODUTO ( id, refrencia, descricao, valoruniti, quantestoque);";

        conexaobd conexao = null;
        PreparedStatement ps = null;

        try {
            conexao = conexaobd.obterConexao();
            ps = conexao.prepareStatement(sql);

            ps.setString(1, produto.getRefrencia());
            ps.setString(2, produto.getDescricao());
            ps.setFloat(3, produto.getValoruniti());
            ps.setInt(4, produto.getQuantestoque());

            ps.execute();
        }finally {
            if (ps != null && !ps.isClosed()){
                ps.close();
            }
            if (conexao != null && !conexao.isClosed()){
                conexao.close();
            }
        }
    }
    public static List<produto> listar()
        throws SQLException, Exception{
        String sql = "SELECT id, refrencia, descricao, valoruniti,quantestoque" + "PRODUTO";
        List<produto> produtoList = null;

        conexaobd conexao = null;
        PreparedStatement ps = null;
        ResultSet resultado = null;

        try {
            conexao = conexaobd.obterConexao();
            ps = conexao.prepareStatement(sql);
            resultado = ps.executeQuery();

            while (resultado.next()) {
                if (produtoList == null) {
                    produtoList = new ArrayList<produto>();
                }
                produto produto = new produto();
                produto.setId(resultado.getInt("id"));
                produto.setRefrencia(resultado.getString("referencia"));
                produto.setDescricao(resultado.getString("descricao"));
                produto.setValoruniti(resultado.getFloat("valoruniti"));
                produto.setQuantestoque(resultado.getInt("quantestoque"));
                produtoList.add(produto);
            }
        }finally {
            if (resultado != null && !resultado.isClosed()){
                resultado.close();
            }
            if (ps != null && !ps.isClosed()){
                ps.close();
            }
            if (conexao != null && !ps.isClosed()){
                conexao.close();
            }
        }
        return  produtoList;
    }

    public static List<produto> procurar(String nome)
        throws SQLException, Exception{
        String sql = "SELECT id, referencia, descricao, valoruniti, quantestoque" + "PRODUTO WHERE nome LIKE (?)";
        List<produto> produtoList = null;

        conexaobd conexao = null;
        PreparedStatement ps = null;
        ResultSet resultado = null;

        try {
            conexao = conexaobd.obterConexao();
            ps = conexao.prepareStatement(sql);

            ps.setString(1, "%" + nome + "%");

            resultado = ps.executeQuery();

            while (resultado.next()) {
                if (produtoList == null) {
                    produtoList = new ArrayList<produto>();
                }
                produto produto = new produto();
                produto.setId(resultado.getInt("id"));
                produto.setRefrencia(resultado.getString("referencia"));
                produto.setDescricao(resultado.getString("descricao"));
                produto.setValoruniti(resultado.getFloat("valoruniti"));
                produto.setQuantestoque(resultado.getInt("quantestoque"));
                produtoList.add(produto);
            }
        } finally {
            if (resultado != null && !resultado.isClosed()) {
                resultado.close();
            }
            if (ps != null && !ps.isClosed()) {
                ps.close();
            }
            if (conexao != null && conexao.isClosed()) {
                conexao.close();
            }
        }
        return produtoList;
    }


    public static produto obter(Integer id)
        throws SQLException, Exception{

        String sql = "SELECT * FROM PRODUTO WHERE id =?";

        conexaobd conexao = null;
        PreparedStatement ps = null;
        ResultSet resultado = null;

        try{
            conexao = conexaobd.obterConexao();
            ps = conexao.prepareStatement(sql);

            ps.setInt(1, id);
            resultado = ps.executeQuery();

            if (resultado.next()){
                produto produto = new produto();
                produto.setId(resultado.getInt("id"));
                produto.setRefrencia(resultado.getString("referencia"));
                produto.setDescricao(resultado.getString("descricao"));
                produto.setValoruniti(resultado.getFloat("valoruniti"));
                produto.setQuantestoque(resultado.getInt("quantestoque"));

                return produto;
            }
        }finally {
            if (resultado != null && !resultado.isClosed()){
                resultado.close();
            }
            if (ps != null && !ps.isClosed()){
                ps.close();
            }
            if (conexao != null && !conexao.isClosed()){
                conexao.close();
            }
        }
        return null;
    }
    public static void atualizar (produto produtoAtualizado)
        throws SQLException, Exception{
        String sql = "UPDATE PRODUTO SET referencia = ? descricao = ? valoruniti = ? quantestoque = ? WHERE id = ?;";

        conexaobd conexao = null;
        PreparedStatement ps = null;

        try {
            conexao = conexaobd.obterConexao();
            ps = conexao.prepareStatement(sql);

            ps.setString(1, produtoAtualizado.getRefrencia());
            ps.setString(2, produtoAtualizado.getDescricao());
            ps.setFloat(3, produtoAtualizado.getValoruniti());
            ps.setInt(4, produtoAtualizado.getQuantestoque());

            ps.executeUpdate();
        }finally {
            if (ps != null && !ps.isClosed()){
                ps.close();
            }
            if (conexao != null && !conexao.isClosed()){
                conexao.close();
            }
        }
    }
    public static void excluir(Integer id)
        throws SQLException, Exception{
        String sql = "DELETE FROM PRODUTO WHERE id = ?";

        conexaobd conexao = null;
        PreparedStatement ps = null;

        try{
            conexao = conexaobd.obterConexao();
            ps = conexao.prepareStatement(sql);
            ps.setInt(1, id);

            ps.executeUpdate();
        }finally {
            if (ps != null && !ps.isClosed()){
                ps.close();
            }
            if (conexao != null && !conexao.isClosed()){
                conexao.close();
            }
        }
    }
    
}
