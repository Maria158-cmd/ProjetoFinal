package service;

import config.conexaobd;
import Classes.Pessoa.endereco;
import Classes.Pessoa.cliente;

import javax.swing.*;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.ResultSet;

public class  Clientedao {

    public static conexaobd conexao;
    public static cliente cliente;
    public static PreparedStatement ps;
    public static ResultSet resultados;


    public static void salvar(cliente cliente)
        throws SQLException, Exception{
        String sql = "INSERT INTO Cliente (id, nome,data_nascimento,cpf,telefone, rua, numero, cep);";

        conexaobd conexaobd = null;
        PreparedStatement preparedStatement = null;

        try{
            conexao = conexaobd.obterConexao();
            ps = conexao.conn.prepareStatement(sql);

            ps.setString(1, String.valueOf(cliente.getId(Integer.parseInt(resultados.getString(1)))));
            ps.setString(2, cliente.getNome());
            ps.setString(3, cliente.getDatanascimento());
            ps.setString(4, cliente.getCpf());
            ps.setString(5, cliente.getTelefone());
            ps.setString(8,cliente.getEndereco().getRua());
            ps.setString(9,cliente.getEndereco().getNumero());
            ps.setString(10,cliente.getEndereco().getCep());

            preparedStatement.execute();
        }finally {
            if (preparedStatement != null && !preparedStatement.isClosed()){
                preparedStatement.close();
            }
            if (conexao != null && !conexaobd.isClosed()){
                conexaobd.close();
            }
        }
    }

    public static List<cliente> listar()
        throws SQLException, Exception{
        String sql = "SELECT id, nome,data_nascimento,cpf,telefone, rua, numero, cep";
        List<cliente> clienteList = null;

        conexaobd conexaobd = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try{
            conexao = conexaobd.obterConexao();
            ps = conexao.conn.prepareStatement(sql);
            resultados = preparedStatement.executeQuery();

            while (resultSet.next()) {
                if (clienteList == null) {
                    clienteList = new ArrayList<cliente>();
                }
                cliente cliente = new cliente();
                cliente.setId(resultados.getInt("id"));
                cliente.setNome(resultados.getString("nome"));
                cliente.setDatanascimento(resultados.getString("Datanascimento"));
                cliente.setCpf(resultados.getString("cpf"));
                cliente.setTelefone(resultados.getString("telefone"));
                endereco endereco = new endereco();
                endereco.getId(Integer.parseInt(resultados.getString("id")));

                clienteList.add(cliente);
            }
        }finally {
            if (resultados != null && !resultados.isClosed()){
                resultados.close();
            }
            if (preparedStatement != null && !preparedStatement.isClosed()){
                preparedStatement.close();
            }
            if (conexao != null && !conexao.isClosed()){
                conexao.close();
            }
        }
        return clienteList;
    }

    public static List<cliente> procurar (String nome)
        throws SQLException, Exception{

        String sql = "SELECT id, nome,data_nascimento,cpf,telefone,rua, numero, cep";
        List<cliente> clienteList = null;

        conexaobd conexaobd = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            conexao = conexaobd.obterConexao();
            ps = conexao.conn.prepareStatement(sql);

            preparedStatement.setString(1, "%" + nome + "%");

            resultados = preparedStatement.executeQuery();

            while (resultados.next()) {
                if (clienteList == null) {
                    clienteList = new ArrayList<cliente>();
                }
                cliente cliente = new cliente();
                cliente.setId(resultados.getInt("id"));
                cliente.setNome(resultados.getString("nome"));
                cliente.setDatanascimento(resultados.getString("Datanascimento"));
                cliente.setCpf(resultados.getString("cpf"));
                cliente.setTelefone(resultados.getString("telefone"));
                endereco endereco = new endereco();
                endereco.getId(Integer.parseInt(resultados.getString("id")));

                clienteList.add(cliente);
            }
        }finally {
            if (resultados != null && !resultados.isClosed()){
                resultados.close();
            }
            if(preparedStatement != null && !preparedStatement.isClosed()){
                preparedStatement.close();
            }
            if (conexao != null && !conexaobd.isClosed()){
                conexao.close();
            }
        }
        return clienteList;
    }

    public static cliente obter(Integer id)
        throws  SQLException, Exception{

        String sql = "SELECT * FROM Cliente id = ?";

        conexaobd conexao = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultado = null;

        try {
            conexao = conexaobd.obterConexao();
            ps = conexao.conn.prepareStatement(sql);

            preparedStatement.setInt(1, id);
            resultado = preparedStatement.executeQuery();

            if (resultado.next()){
                cliente cliente = new cliente();
                cliente.setId(resultados.getInt("id"));
                cliente.setNome(resultados.getString("nome"));
                cliente.setDatanascimento(resultados.getString("Datanascimento"));
                cliente.setCpf(resultados.getString("cpf"));
                cliente.setTelefone(resultados.getString("telefone"));
                endereco endereco = new endereco();
                endereco.getId(Integer.parseInt(resultados.getString("id")));

                return cliente;
            }
        }finally {
            if (resultado != null && !resultado.isClosed()){
                resultado.close();
            }
            if (preparedStatement != null && !preparedStatement.isClosed()){
                preparedStatement.close();
            }
            if (conexao != null && !conexao.isClosed()){
                conexao.close();
            }
        }
        return null;
    }
    public static cliente obter2 (String cpf)
        throws SQLException, Exception {
        String sql = "SELECT * FROM Cliente WHERE cpf =?";

        conexaobd conexaobd = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultado = null;

        try {
            conexao = conexaobd.obterConexao();
            ps = conexao.conn.prepareStatement(sql);

            preparedStatement.setString(1, cpf);
            resultado = preparedStatement.executeQuery();

            if (resultado.next()) {
                cliente cliente = new cliente();
                cliente.setId(resultados.getInt("id"));
                cliente.setNome(resultados.getString("nome"));
                cliente.setDatanascimento(resultados.getString("Datanascimento"));
                cliente.setCpf(resultados.getString("cpf"));
                cliente.setTelefone(resultados.getString("telefone"));
                endereco endereco = new endereco();
                endereco.getId(Integer.parseInt(resultados.getString("id")));

                return cliente;
            }
        } finally {
            if (resultado != null && !resultado.isClosed()) {
                resultado.close();
            }
            if (preparedStatement != null && !preparedStatement.isClosed()) {
                preparedStatement.close();
            }
            if (conexao != null && !preparedStatement.isClosed()) {
                conexao.close();
            }
        }
        return null;
    }

        public static void atualizar (cliente clienteAtualizado) {

            String sql = "UPDATE cliente SET nome = ?,data_nascimento = ?,cpf = ?,telefone = ?, WHERE id = ?;";
            conexaobd conexaobd = null;


            try {
                conexaobd = conexaobd.obterConexao();
                ps = conexao.conn.prepareStatement(sql);

                ps.setInt(1, clienteAtualizado.getId(Integer.parseInt(resultados.getString(1))));
                ps.setString(2, clienteAtualizado.getNome());
                ps.setString(3, clienteAtualizado.getDatanascimento());
                ps.setString(4, clienteAtualizado.getCpf());
                ps.setString(5, clienteAtualizado.getTelefone());

                ps.executeUpdate();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Registro nao encontrado");

            } finally {
                if (conexaobd != null && !conexaobd.isClosed()) {
                    conexaobd.close();
                }
            }
        }

        public static void excluir (Integer id)
            throws  SQLException, Exception{
            String sql = "DELETE FROM cliente WHERE id = ?";

            conexaobd conexaobd = null;
            PreparedStatement preparedStatement = null;

            try{
                conexaobd = conexao.obterConexao();
                ps = conexao.prepareStatement(sql);
                ps.setInt(1, id);

                ps.executeUpdate();
            }finally {
                if (ps != null && ! ps.isClosed()){
                    ps.close();
                }
                if (conexao != null && !conexao.isClosed()){
                    conexao.close();
                }
            }
    }
}
