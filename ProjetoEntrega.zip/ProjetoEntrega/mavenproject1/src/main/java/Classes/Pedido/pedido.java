package Classes.Pedido;
import java.util.ArrayList;
import java.util.Date;
import Classes.Pessoa.cliente;
import Classes.Pessoa.endereco;
import Classes.Pessoa.entregador;

public class pedido {
    private Integer id;
    private Date data;
    private Float subtotal;
    private Float taxaentrega;
    private Float valortotal;
    private Float pagamentoDinheiro;
    private Float pagamentoCartao;
    private endereco endereco;
    private cliente cliente;
    private entregador entregador;
    private ArrayList<itempedido> itempedidos = new ArrayList<itempedido>();
    private Integer qtdItens;

    public pedido(Integer id, Date data, Float subtotal, Float taxaentrega, Float valortotal, Float pagamentoDinheiro, Float pagamentoCartao, Classes.Pessoa.endereco endereco, Classes.Pessoa.cliente cliente, Classes.Pessoa.entregador entregador, ArrayList<itempedido> itempedidos, Integer qtdItens) {
        this.id = id;
        this.data = data;
        this.subtotal = subtotal;
        this.taxaentrega = taxaentrega;
        this.valortotal = valortotal;
        this.pagamentoDinheiro = pagamentoDinheiro;
        this.pagamentoCartao = pagamentoCartao;
        this.endereco = endereco;
        this.cliente = cliente;
        this.entregador = entregador;
        this.itempedidos = itempedidos;
        this.qtdItens = qtdItens;
    }

    public pedido() {

    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public Float getSubtotal(float subTotal) {
        return subtotal;
    }

    public void setSubtotal(Float subtotal) {
        this.subtotal = subtotal;
    }

    public Float getTaxaentrega() {
        return taxaentrega;
    }

    public void setTaxaentrega(Float taxaentrega) {
        this.taxaentrega = taxaentrega;
    }

    public Float getValortotal() {
        return valortotal;
    }

    public void setValortotal(Float valortotal) {
        this.valortotal = valortotal;
    }

    public Float getPagamentoDinheiro() {
        return pagamentoDinheiro;
    }

    public void setPagamentoDinheiro(Float pagamentoDinheiro) {
        this.pagamentoDinheiro = pagamentoDinheiro;
    }

    public Float getPagamentoCartao() {
        return pagamentoCartao;
    }

    public void setPagamentoCartao(Float pagamentoCartao) {
        this.pagamentoCartao = pagamentoCartao;
    }

    public Classes.Pessoa.endereco getEndereco() {
        return endereco;
    }

    public void setEndereco(Classes.Pessoa.endereco endereco) {
        this.endereco = endereco;
    }

    public Classes.Pessoa.cliente getCliente() {
        return cliente;
    }

    public void setCliente(Classes.Pessoa.cliente cliente) {
        this.cliente = cliente;
    }

    public Classes.Pessoa.entregador getEntregador() {
        return entregador;
    }

    public void setEntregador(Classes.Pessoa.entregador entregador) {
        this.entregador = entregador;
    }

    public ArrayList<itempedido> getItempedidos() {
        return itempedidos;
    }

    public void setItempedidos(ArrayList<itempedido> itempedidos) {
        this.itempedidos = itempedidos;
    }

    public Integer getQtdItens() {
        return qtdItens;
    }

    public void setQtdItens(Integer qtdItens) {
        this.qtdItens = qtdItens;
    }

    public void getQtdItens(int qtditens) {
    }

    public void getTaxaentrega(float taxaEntrega) {
    }

    public void getValortotal(float valorTotal) {
    }

    public void getPagamentoDinheiro(float pagamentoDinheiro) {
    }

    public void getPagamentoCartao(float pagamentoCartao) {
    }
    
}
