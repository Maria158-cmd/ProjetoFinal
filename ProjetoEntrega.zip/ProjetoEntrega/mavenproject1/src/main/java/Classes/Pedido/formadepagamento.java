package Classes.Pedido;

public class formadepagamento {
    private Integer id;
    private Integer tipopag;
    private Integer numvezes;

    public formadepagamento(Integer id, Integer tipopag, Integer numvezes) {
        this.id = id;
        this.tipopag = tipopag;
        this.numvezes = numvezes;
    }

    public formadepagamento() {

    }

    public Integer getTipopag() {
        return tipopag;
    }

    public void setTipopag(Integer tipopag) {
        this.tipopag = tipopag;
    }

    public Integer getNumvezes() {
        return numvezes;
    }

    public void setNumvezes(Integer numvezes) {
        this.numvezes = numvezes;
    }

    public Integer getId(int i) {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
    
}
